.. toctree::
   :caption: Attendance Log Operation
   :name: topic3

########################
Attendance Log Operation
########################


Get Attendance Log
------------------

Clear Attendance Log
--------------------

